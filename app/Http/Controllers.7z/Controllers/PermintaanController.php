<?php

namespace App\Http\Controllers;

use App\Models\Permintaan;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;

class PermintaanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Ambil data dari database
        $data = DB::table('permintaan_header')
                ->leftjoin('pengguna', 'pengguna.pengguna_id', '=', 'permintaan_header.pengguna_id')
                ->leftjoin('masterunit', 'masterunit.unit_id', '=', 'permintaan_header.unit_id')
                ->leftjoin('supplier', 'supplier.supplier_id', '=', 'permintaan_header.supplier_id')
                // ->orderBy(['permintaan_header_id' => 'asc'])
                ->get();
        
        // Memanggil view dengan memasukan variabel data
        return view('permintaan.index', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $data = DB::table('masterbarang')
                ->orderBy('barang_nama','asc')
                ->get();
        return view('permintaan.create', ['data' => $data]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $userid = '033123';
        // Mengambil data dari form tambah
        $request->validate([
            'id'            => 'required',
            'supplier'      => 'required',
            'keterangan'    => 'required',
            'namakaryawan'  => 'required',
            'nomor'         => 'required'
        ]);
        //dd($request);
        // Mencari data unit berdasarkan pengguna id
        $data = DB::table('pengguna')
                ->where('pengguna_id', '=', $userid)
                ->get();
        
        // Memasukan data unit id untuk masuk ke variabel $unit_id
        foreach($data as $item){
            $unit_id = $item->unit_id;
        }
        
        $date = date('Y-m-d');
        //dd($date);
        $count = $request->nomor;
        // dd($count);

        // Memasukan data ke dalam database tabel header
         DB::table('permintaan_header')->insert([
            'permintaan_header_id'          => $request->id,
            'permintaan_header_tgl'         => $date,
            'pengguna_id'                   => $userid,
            'unit_id'                       => $unit_id,
            'supplier_id'                   => $request->supplier,
            'permintaan_header_keterangan'  => $request->keterangan,
            'karyawan'                      => $request->namakaryawan
        ]);
        //return redirect('permintaan')->with('sukses', 'Data User Berhasil ditambah!');
        // Perulangan untuk masuk ke tabel permintaan detail
        for($i = 0; $i <= $count; $i++){
            $request->validate([
                'barang_'.$i        => 'required',
                'jumlah_'.$i        => 'nullable',
                'hargasatuan_'.$i   => 'nullable'
            ]);
            
            //dd($request);
            $detail_id = $request->id.'_'.rand(1,10000);
            // memasukan data ke dalam tabel permintaan detail
            DB::table('permintaan_detail')->insert([
               'permintaan_detail_id'           => $detail_id,
               'permintaan_header_id'           => $request->id,
               'barang_id'                      => $request->{'barang_'.$i},
               'permintaan_detail_jumlah'       => $request->{'jumlah_'.$i},
               'permintaan_detail_harga_satuan' => $request->{'hargasatuan_'.$i}
            ]);
            // if($request->{'barang_'.$i}!=="0"){
            //     // generate id permintaan detail
            //     $detail_id = $request->id.'_'.rand(1,10000);
            //     // memasukan data ke dalam tabel permintaan detail
            //     DB::table('permintaan_detail')->insert([
            //         'permintaan_detail_id'           => $detail_id,
            //         'permintaan_header_id'           => $request->id,
            //         'barang_id'                      => $request->{'barang_'.$i},
            //         'permintaan_detail_jumlah'       => $request->{'jumlah_'.$i},
            //         'permintaan_detail_harga_satuan' => $request->{'hargasatuan_'.$i}
            //     ]);

            // }else{
            //     //dd($request);
            //     echo "masuk ke else";
            //     //return redirect('permintaan')->with('sukses', 'Data User Berhasil ditambah!');
            // }
            
        }
        return redirect('/permintaan');
        //return redirect('permintaan')->with('sukses', 'Data User Berhasil ditambah!');

    }

    /**
     * Display the specified resource.
     */
    public function show(Request $request)
    {
        //
        $userid = '033123';
        // Mengambil data dari form tambah
        $request->validate([
            'id'            => 'required',
            'supplier'      => 'required',
            'keterangan'    => 'required',
            'namakaryawan'  => 'required'
        ]);
        $databarang = [];
        $datajumlah = [];
        for($i = 1; $i <= 10; $i++){
            
            $databarang[] = $request->input('barang_'.$i);
            $datajumlah[] = $request->input('jumlah_'.$i);
            
        }
        // dd(
        //     $request->input('barang_1'), 
        //     $request->input('barang_2'), 
        //     $request->input('barang_3'),
        //     $request->input('jumlah_1'), 
        //     $request->input('jumlah_2'), 
        //     $request->input('jumlah_3'),
        //     $databarang, $datajumlah
        // );
        $masterbarang = DB::table('masterbarang')
                        ->orderBy('barang_nama','asc')
                        ->get(); 

        // Memanggil view dengan memasukan variabel data
        return view('permintaan.show', ['request' => $request,
        'databarang' => $databarang, 
        'datajumlah' => $datajumlah, 
        'masterbarang' => $masterbarang]);

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Permintaan $permintaan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Permintaan $permintaan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Permintaan $permintaan)
    {
        //
    }
}
